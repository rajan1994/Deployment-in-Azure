# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
import json
import logging
import os
import pickle
import numpy as np
import pandas as pd
from sklearn.externals import joblib

import azureml.automl.core
from azureml.automl.core.shared import logging_utilities, log_server
from azureml.telemetry import INSTRUMENTATION_KEY

from inference_schema.schema_decorators import input_schema, output_schema
from inference_schema.parameter_types.numpy_parameter_type import NumpyParameterType
from inference_schema.parameter_types.pandas_parameter_type import PandasParameterType


input_sample = pd.DataFrame({"Province": pd.Series(["Bretagne"], dtype="object"), "Region": pd.Series(["West"], dtype="object"), "Trip_Length_Mean": pd.Series(["18.10325"], dtype="float64"), "Trip_Length_Sigma": pd.Series(["6.034416"], dtype="float64"), "Trips_Per_Day_Mean": pd.Series(["4.733162"], dtype="float64"), "Trips_Per_Day_Sigma": pd.Series(["1.183291"], dtype="float64"), "Battery_Rated_Cycles": pd.Series(["275"], dtype="int64"), "Manufacture_Month": pd.Series(["M8"], dtype="object"), "Manufacture_Year": pd.Series(["Y2010"], dtype="object"), "Alternator_Efficiency": pd.Series(["0.9812054"], dtype="float64"), "Car_Has_EcoStart": pd.Series(["False"], dtype="bool"), "Twelve_hourly_temperature_history_for_last_31_days_before_death_last_recording_first": pd.Series(["15.47809"], dtype="float64"), "Sensor_Reading_1": pd.Series(["6.143313"], dtype="float64"), "Sensor_Reading_2": pd.Series(["6.450575"], dtype="float64"), "Sensor_Reading_3": pd.Series(["13.06294"], dtype="float64"), "Sensor_Reading_4": pd.Series(["9.646868"], dtype="float64"), "Sensor_Reading_5": pd.Series(["11.52591"], dtype="float64"), "Sensor_Reading_6": pd.Series(["6.71553"], dtype="float64"), "Sensor_Reading_7": pd.Series(["12.69211"], dtype="float64"), "Sensor_Reading_8": pd.Series(["8.938579"], dtype="float64"), "Sensor_Reading_9": pd.Series(["11.60053"], dtype="float64"), "Sensor_Reading_10": pd.Series(["19.78082"], dtype="float64"), "Sensor_Reading_11": pd.Series(["13.32407"], dtype="float64"), "Sensor_Reading_12": pd.Series(["10.51005"], dtype="float64"), "Sensor_Reading_13": pd.Series(["13.34349"], dtype="float64"), "Sensor_Reading_14": pd.Series(["17.7107"], dtype="float64"), "Sensor_Reading_15": pd.Series(["9.367179"], dtype="float64"), "Sensor_Reading_16": pd.Series(["10.16107"], dtype="float64"), "Sensor_Reading_17": pd.Series(["9.894401"], dtype="float64"), "Sensor_Reading_18": pd.Series(["10.02929"], dtype="float64"), "Sensor_Reading_19": pd.Series(["12.48455"], dtype="float64"), "Sensor_Reading_20": pd.Series(["15.76229"], dtype="float64"), "Sensor_Reading_21": pd.Series(["14.60924"], dtype="float64"), "Sensor_Reading_22": pd.Series(["9.598007"], dtype="float64"), "Sensor_Reading_23": pd.Series(["12.47891"], dtype="float64"), "Sensor_Reading_24": pd.Series(["9.551459"], dtype="float64"), "Sensor_Reading_25": pd.Series(["6.300238"], dtype="float64"), "Sensor_Reading_26": pd.Series(["23.94306"], dtype="float64"), "Sensor_Reading_27": pd.Series(["11.70371"], dtype="float64"), "Sensor_Reading_28": pd.Series(["9.051233"], dtype="float64"), "Sensor_Reading_29": pd.Series(["12.57748"], dtype="float64"), "Sensor_Reading_30": pd.Series(["19.92233"], dtype="float64"), "Sensor_Reading_31": pd.Series(["11.0444"], dtype="float64"), "Sensor_Reading_32": pd.Series(["10.83924"], dtype="float64"), "Sensor_Reading_33": pd.Series(["13.4063"], dtype="float64"), "Sensor_Reading_34": pd.Series(["6.632585"], dtype="float64"), "Sensor_Reading_35": pd.Series(["16.63693"], dtype="float64"), "Sensor_Reading_36": pd.Series(["18.72788"], dtype="float64"), "Sensor_Reading_37": pd.Series(["7.187799"], dtype="float64"), "Sensor_Reading_38": pd.Series(["20.54837"], dtype="float64"), "Sensor_Reading_39": pd.Series(["14.132"], dtype="float64"), "Sensor_Reading_40": pd.Series(["10.65695"], dtype="float64"), "Sensor_Reading_41": pd.Series(["8.866134"], dtype="float64"), "Sensor_Reading_42": pd.Series(["13.74479"], dtype="float64"), "Sensor_Reading_43": pd.Series(["15.15716"], dtype="float64"), "Sensor_Reading_44": pd.Series(["20.91986"], dtype="float64"), "Sensor_Reading_45": pd.Series(["7.981845"], dtype="float64"), "Sensor_Reading_46": pd.Series(["10.78637"], dtype="float64"), "Sensor_Reading_47": pd.Series(["3.328168"], dtype="float64"), "Sensor_Reading_48": pd.Series(["13.16197"], dtype="float64"), "Sensor_Reading_49": pd.Series(["12.28234"], dtype="float64"), "Sensor_Reading_50": pd.Series(["17.12672"], dtype="float64"), "Sensor_Reading_51": pd.Series(["14.42337"], dtype="float64"), "Sensor_Reading_52": pd.Series(["16.41891"], dtype="float64"), "Sensor_Reading_53": pd.Series(["17.44131"], dtype="float64"), "Sensor_Reading_54": pd.Series(["24.71829"], dtype="float64"), "Sensor_Reading_55": pd.Series(["11.81231"], dtype="float64"), "Sensor_Reading_56": pd.Series(["19.43721"], dtype="float64"), "Sensor_Reading_57": pd.Series(["15.07974"], dtype="float64"), "Sensor_Reading_58": pd.Series(["16.98244"], dtype="float64"), "Sensor_Reading_59": pd.Series(["18.89361"], dtype="float64"), "Sensor_Reading_60": pd.Series(["13.59"], dtype="float64"), "Sensor_Reading_61": pd.Series(["14.51094"], dtype="float64")})
output_sample = np.array([0])
try:
    log_server.enable_telemetry(INSTRUMENTATION_KEY)
    log_server.set_verbosity('INFO')
    logger = logging.getLogger('azureml.automl.core.scoring_script')
except:
    pass


def init():
    global model
    # This name is model.id of model that we want to deploy deserialize the model file back
    # into a sklearn model
    model_path = os.path.join(os.getenv('AZUREML_MODEL_DIR'), 'model.pkl')
    try:
        model = joblib.load(model_path)
    except Exception as e:
        path = os.path.normpath(model_path)
        path_split = path.split(os.sep)
        log_server.update_custom_dimensions({'model_name': path_split[1], 'model_version': path_split[2]})
        logging_utilities.log_traceback(e, logger)
        raise


@input_schema('data', PandasParameterType(input_sample))
@output_schema(NumpyParameterType(output_sample))
def run(data):
    try:
        result = model.predict(data)
        return json.dumps({"result": result.tolist()})
    except Exception as e:
        result = str(e)
        return json.dumps({"error": result})
